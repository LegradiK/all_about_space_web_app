import os
import re
import html
import requests
from datetime import datetime, timedelta
import random
import pytz
from flask import Flask, render_template, Response, jsonify
from dotenv import load_dotenv


def rocketlaunch_url(name):
    slug = name.lower()
    slug = re.sub(r'\s*\|\s*', '-', slug)
    slug = slug.replace(' ', '-')
    slug = re.sub(r'[^a-z0-9-]', '', slug)
    slug = re.sub(r'-+', '-', slug).strip('-')
    return f'https://rocketlaunch.org/mission-{slug}'


# Load data.env from this file's folder, whatever the working directory is (matters on PythonAnywhere)
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.env"))

NASA_API = os.getenv('NASA_API')

app = Flask(__name__)

# Imported after load_dotenv so the alert settings in data.env are available
from alerts import alerts_bp
app.register_blueprint(alerts_bp)

def format_date(date_str):
    dt = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%SZ')
    dt = dt.replace(tzinfo=pytz.utc)
    uk_tz = pytz.timezone('Europe/London')
    uk_time = dt.astimezone(uk_tz)
    return uk_time.strftime('%Y %m %d , %H:%M %Z')

def strip_html(text):
    # The new APOD API returns explanation/credit/copyright as HTML fragments
    text = re.sub(r'<[^>]+>', '', text or '')
    return html.unescape(text).strip()


def split_first_sentence(text):
    # Split after the first . ! or ? that is followed by a space and a capital letter,
    # so abbreviations like "e.g. the" don't cut the sentence short
    parts = re.split(r'(?<=[.!?])\s+(?=[A-Z"\u201c(])', text or '', maxsplit=1)
    first = parts[0].strip()
    rest = parts[1].strip() if len(parts) > 1 else ''
    return first, rest


def get_apod():
    # APOD moved to science.nasa.gov on 2026-09-29. The old
    # api.nasa.gov/planetary/apod endpoint now returns a placeholder
    # (NASA logo, "NASA Science") or 503/504, and retires on 2026-12-01.
    # The new endpoint needs no API key.
    try:
        response = requests.get(
            'https://science.nasa.gov/wp-json/wp/v2/apod-basic',
            params={
                'per_page': 1,
                '_fields': 'date,title,media_type,explanation,credit,copyright,alt,url,hdurl,permalink'
            },
            timeout=15
        )
        response.raise_for_status()
        data = response.json()
        if not data:
            print("APOD: empty response")
            return None
        item = data[0]  # the endpoint returns a list, newest first
        explanation = strip_html(item.get('explanation'))
        summary, more = split_first_sentence(explanation)
        return {
            'date': item.get('date'),
            'title': strip_html(item.get('title')),
            'media_type': item.get('media_type'),
            'explanation': explanation,
            'summary': summary,   # first sentence, shown by default
            'more': more,         # the rest, revealed by "Read more"
            'copyright': strip_html(item.get('copyright') or item.get('credit')),
            'alt': item.get('alt'),
            # 'url' is now the article page, 'hdurl' is the actual image
            'url': item.get('hdurl'),
            'hdurl': item.get('hdurl'),
            'permalink': item.get('permalink') or item.get('url'),
            'source_url': item.get('hdurl') or item.get('permalink'),
        }
    except Exception as e:
        print("APOD fetch failed:", e)
        return None

def get_epic():
    # Call the EPIC server directly (no API key needed) instead of
    # going through the api.nasa.gov gateway
    try:
        response = requests.get(
            'https://epic.gsfc.nasa.gov/api/natural',
            timeout=15
        )
        response.raise_for_status()
        images = response.json()
        if not images:
            print("EPIC: no images returned")
            return None
        random.shuffle(images)
        result = []
        for img in images[:2]:
            date = img['date'][:10].replace('-', '/')
            url = f"https://epic.gsfc.nasa.gov/archive/natural/{date}/jpg/{img['image']}.jpg"
            result.append({'url': url, 'title': img['caption']})
        return result
    except Exception as e:
        print("EPIC failed:", e)
        return None

def get_iss_position():
    if not NASA_API:
        print("ERROR: NASA_API key not found in .env")
        return None
    try:
        response = requests.get(
            "https://api.wheretheiss.at/v1/satellites/25544",
            headers={"User-Agent": "space-dashboard/1.0"},
            timeout=10,
        )    
        response.raise_for_status()
        data = response.json()
        return {
            "lat": data["latitude"],
            "lon": data["longitude"],
            "alt_km": data["altitude"],
            "speed_kmh": data["velocity"],
            "visibility": data["visibility"],
            "timestamp": data["timestamp"],
        }
    except Exception as e:
        print("ISS tracking failed:", e)
        return None

def get_neows():
    if not NASA_API:
        print("ERROR: NASA_API key not found in .env")
        return None
    try:
        today = datetime.today().date()
        search_end_day = today + timedelta(days=7)
        response = requests.get(
            "https://api.nasa.gov/neo/rest/v1/feed",
            params={
                "start_date": str(today),
                "end_date": str(search_end_day),
                "api_key": NASA_API
            }
        )
        response.raise_for_status()
        data = response.json()
        asteroids = []
        for date in data['near_earth_objects']:
            for r in data['near_earth_objects'][date]:
                asteroids.append({
                    'name': r['name'],
                    'date': r['close_approach_data'][0]['close_approach_date'],
                    'distance': round(float(r['close_approach_data'][0]['miss_distance']['kilometers'])),
                    'dangerous': r['is_potentially_hazardous_asteroid'],
                    'url': r['nasa_jpl_url']
                })
        random.shuffle(asteroids)
        asteroids.sort(key=lambda x: x['date'])
        return asteroids[:10]
    except Exception as e:
        print("NeoWs failed:", e)
        return None

# The Space Devs allow only 15 anonymous requests per hour, so cache the
# result instead of calling the API on every page view.
LAUNCH_CACHE_SECONDS = 15 * 60
_launch_cache = {'data': None, 'fetched_at': None}


def fetch_launches():
    response = requests.get(
        'https://ll.thespacedevs.com/2.3.0/launches/upcoming/',
        params={'limit': 5, 'format': 'json'},
        timeout=15
    )
    response.raise_for_status()
    data = response.json()
    launches = []
    for r in data['results']:
        launches.append({
            'name': r['name'],
            'date': format_date(r['net']),
            'status': r['status']['name'],
            'location': r['pad']['location']['name'],
            'url': rocketlaunch_url(r['name']),
            'image': r.get('image'),
            'mission': r['mission']['description'] if r.get('mission') else None
        })
    return launches


def get_launches():
    now = datetime.now()
    fetched_at = _launch_cache['fetched_at']

    # Serve from cache while it's fresh
    if fetched_at and now - fetched_at < timedelta(seconds=LAUNCH_CACHE_SECONDS):
        return _launch_cache['data']

    try:
        _launch_cache['data'] = fetch_launches()
        _launch_cache['fetched_at'] = now
    except Exception as e:
        # e.g. 429 Too Many Requests: keep showing the last good data
        print("Launches failed:", e)
        if _launch_cache['data'] is not None:
            # Don't retry on every page view; wait 5 minutes before trying again
            _launch_cache['fetched_at'] = now - timedelta(seconds=LAUNCH_CACHE_SECONDS - 5 * 60)
    return _launch_cache['data']

@app.route('/api/aurora-status')
def aurora_proxy():
    r = requests.get('https://aurorawatch-api.lancs.ac.uk/0.2.5/status/alerting-site-activity.xml')
    return Response(r.content, content_type='application/xml')


# NOAA updates the OVATION forecast about every 5 minutes, so cache it
# rather than downloading the ~1 MB file on every page view.
AURORA_WORLD_CACHE_SECONDS = 5 * 60
_aurora_world_cache = {'data': None, 'fetched_at': None}


def fetch_aurora_world():
    response = requests.get(
        'https://services.swpc.noaa.gov/json/ovation_aurora_latest.json',
        timeout=20
    )
    response.raise_for_status()
    data = response.json()
    cells = []
    for lon, lat, prob in data['coordinates']:
        if prob < 1:
            continue  # most of the globe is 0%, no need to send it
        if lon > 180:
            lon -= 360  # NOAA uses 0-359, D3 expects -180 to 180
        cells.append([lon, lat, prob])
    return {
        'observation_time': data.get('Observation Time'),
        'forecast_time': data.get('Forecast Time'),
        'cells': cells,
    }


@app.route('/api/aurora-world')
def aurora_world():
    now = datetime.now()
    fetched_at = _aurora_world_cache['fetched_at']
    if not fetched_at or now - fetched_at >= timedelta(seconds=AURORA_WORLD_CACHE_SECONDS):
        try:
            _aurora_world_cache['data'] = fetch_aurora_world()
            _aurora_world_cache['fetched_at'] = now
        except Exception as e:
            print("Aurora world forecast failed:", e)
    if _aurora_world_cache['data'] is None:
        return jsonify({'error': 'Forecast unavailable'}), 503
    return jsonify(_aurora_world_cache['data'])

@app.route('/')
def home():
    apod = get_apod()
    epic = get_epic()
    return render_template("home.html", apod=apod, epic=epic)

@app.route('/iss')
def iss_page():
    iss_tracking = get_iss_position()
    return render_template("iss.html", iss=iss_tracking)

@app.route('/launches')
def launches_page():
    launches = get_launches()
    return render_template("launches.html", launches=launches)

@app.route('/asteroids')
def asteroids_page():
    neows = get_neows()
    return render_template("asteroids.html", neows=neows)

@app.route('/aurora')
def aurora_page():
    return render_template("aurora.html")


if __name__ == "__main__":
    app.run(debug=True)